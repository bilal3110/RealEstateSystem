@include('html.layout.head')
{{-- @include('html.layout.nav') --}}
@include('html.layout.side')
@yield('main-section')
@include('html.layout.footer')