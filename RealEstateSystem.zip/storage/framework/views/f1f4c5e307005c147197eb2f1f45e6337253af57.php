
<?php $__env->startSection('main-section'); ?>

    <body>
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Menu -->
                <!-- / Menu -->

                <!-- Layout container -->
                <div class="layout-page">
                    <!-- Navbar -->
                    <?php echo $__env->make('html.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- / Navbar -->

                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->
                        <div class="container-xxl flex-grow-1 container-p-y">
                            <div class="row">
                                <h3>Sold Out Properties</h3>
                                <div class="col-lg-12 mb-4 order-0">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <?php echo e(session('success')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php else: ?>
                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                <?php echo e(session('error')); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                    aria-label="Close"></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <span class="d-flex">
                                        <form action="<?php echo e(route('SaleOutDisplay')); ?>" method="GET" class="d-flex gap-2">
                                            <div class="mb-3">
                                                <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2"
                                                    placeholder="Search..." aria-label="Search..." name="search" />
                                            </div>
                                            <div>
                                                <input type="submit" class="btn btn-primary">
                                            </div>
                                            <div>
                                                <a href="<?php echo e(route('SaleOutDisplay')); ?>" class="btn btn-success">Reset</a>
                                            </div>
                                        </form>
                                    </span>
                                    <div class="card">
                                        <h5 class="card-header">Processed Table</h5>
                                        <div class="table-responsive text-nowrap">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Property</th>
                                                        <th>Seller</th>
                                                        <th>Seller CNIC</th>
                                                        <th>Area</th>
                                                        <th>Price</th>
                                                        <th>Buyer</th>
                                                        <th>Buyer CNIC</th>
                                                        <th>Commission</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-border-bottom-0">
                                                    <?php $__currentLoopData = $process; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($sale->prop_title); ?></td>
                                                            <td><?php echo e($sale->landlord_name); ?></td>
                                                            <td><?php echo e($sale->landlord_cnic); ?></td>
                                                            <td><?php echo e($sale->prop_area); ?></td>
                                                            <td><?php echo e(number_format((float) str_replace(',', '', $sale->prop_price))); ?>

                                                            </td>
                                                            <td><?php echo e($sale->buyer_name); ?></td>
                                                            <td><?php echo e($sale->buyer_cnic); ?></td>
                                                            <td><?php echo e(number_format((float) str_replace(',', '', $sale->commission))); ?>

                                                            </td>
                                                            <td>
                                                                <div class="dropdown">
                                                                    <button type="button"
                                                                        class="btn p-0 dropdown-toggle hide-arrow"
                                                                        data-bs-toggle="dropdown">
                                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                                    </button>
                                                                    <div class="dropdown-menu">
                                                                        <a class="dropdown-item"
                                                                            href="<?php echo e(route('soldOutDisplaySingle', $sale->prop_id)); ?>"><i
                                                                                class="fa-regular fa-eye me-1"></i>
                                                                            Preview</a>
                                                                        <a class="dropdown-item"
                                                                            href="<?php echo e(route('SaleOutDelete', $sale->prop_id)); ?>"><i
                                                                                class="bx bx-trash me-1"></i> Delete</a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="demo-inline-spacing">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        
                                                        <?php if($process->onFirstPage()): ?>
                                                            <li class="page-item prev disabled">
                                                                <a class="page-link" href="#" aria-disabled="true">
                                                                    <i class="tf-icon bx bx-chevron-left"></i>
                                                                </a>
                                                            </li>
                                                        <?php else: ?>
                                                            <li class="page-item prev">
                                                                <a class="page-link"
                                                                    href="<?php echo e($process->previousPageUrl()); ?>">Previous</a>
                                                            </li>
                                                        <?php endif; ?>

                                                        
                                                        <?php $__currentLoopData = range(1, $process->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($page == $process->currentPage()): ?>
                                                                <li class="page-item active">
                                                                    <a class="page-link"
                                                                        href="javascript:void(0)"><?php echo e($page); ?></a>
                                                                </li>
                                                            <?php else: ?>
                                                                <li class="page-item">
                                                                    <a class="page-link"
                                                                        href="<?php echo e($process->url($page)); ?>"><?php echo e($page); ?></a>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <?php if($process->hasMorePages()): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="<?php echo e($process->nextPageUrl()); ?>">
                                                                    <i class="tf-icon bx bx-chevron-right"></i>
                                                                </a>
                                                            </li>
                                                        <?php else: ?>
                                                            <li class="page-item next disabled">
                                                                <a class="page-link" href="#" aria-disabled="true">
                                                                    <i class="tf-icon bx bx-chevron-right"></i>
                                                                </a>
                                                            </li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Row -->
                        </div>
                        <!-- / Content -->


                    <?php $__env->stopSection(); ?>

<?php echo $__env->make('html.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RealEstateSystem\resources\views/html/sold-out.blade.php ENDPATH**/ ?>