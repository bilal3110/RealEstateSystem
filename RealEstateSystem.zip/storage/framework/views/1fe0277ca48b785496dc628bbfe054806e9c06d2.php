
<?php $__env->startSection('main-section'); ?>

    <body>
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Menu -->
                <!-- / Menu -->

                <!-- Layout container -->
                <div class="layout-page">
                    <!-- Navbar -->
                    <?php echo $__env->make('html.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- / Navbar -->

                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->

                        <div class="container-xxl flex-grow-1 container-p-y">
                            <div class="row">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('success')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert"
                                            aria-label="Close"></button>
                                    </div>
                                <?php else: ?>
                                    <?php if(session('error')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?php echo e(session('error')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <div class="col-lg-6 mb-4 order-0">
                                    <div class="card">
                                        <h5 class="card-header"><?php echo e($investment->prop_title); ?></h5>
                                        <div class="card-body">
                                            <!-- Bootstrap carousel -->
                                            <div class="col-md">
                                                <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                                                    <!-- Carousel Indicators -->
                                                    <div class="carousel-indicators">
                                                        <?php
                                                            $images = is_array($investment->prop_img)
                                                                ? $investment->prop_img
                                                                : (is_string($investment->prop_img)
                                                                    ? json_decode($investment->prop_img, true)
                                                                    : []);
                                                            $imageCount =
                                                                !empty($images) && is_array($images)
                                                                    ? count($images)
                                                                    : 1; // Default to 1 if no images
                                                        ?>

                                                        <?php if($imageCount > 0): ?>
                                                            <?php for($i = 0; $i < $imageCount; $i++): ?>
                                                                <button type="button" data-bs-target="#carouselExample"
                                                                    data-bs-slide-to="<?php echo e($i); ?>"
                                                                    class="<?php echo e($i == 0 ? 'active' : ''); ?>"
                                                                    aria-current="<?php echo e($i == 0 ? 'true' : 'false'); ?>"
                                                                    aria-label="Slide <?php echo e($i + 1); ?>"></button>
                                                            <?php endfor; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <!-- Carousel Items -->
                                                    <div class="carousel-inner">
                                                        <?php if(!empty($images) && is_array($images) && count($images) > 0): ?>
                                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div
                                                                    class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                                    <img class="d-block w-100" src="<?php echo e(asset($image)); ?>"
                                                                        alt="Property Image <?php echo e($index + 1); ?>" />
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <div class="carousel-item active">
                                                                <img class="d-block w-100"
                                                                    src="<?php echo e(asset('storage/image/4.png')); ?>"
                                                                    alt="Default Image" />
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <a class="carousel-control-prev" href="#carouselExample" role="button"
                                                        data-bs-slide="prev">
                                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                        <span class="visually-hidden">Previous</span>
                                                    </a>
                                                    <a class="carousel-control-next" href="#carouselExample" role="button"
                                                        data-bs-slide="next">
                                                        <span class="carousel-control-next-icon"
                                                            aria-hidden="true"></span>
                                                        <span class="visually-hidden">Next</span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col my-3">
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Buying Price: <small
                                                        class="text-dark"><?php echo e($investment->buying_price); ?></small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Location: <small class="text-dark"><?php echo e($investment->prop_loc); ?></small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Area: <small class="text-dark"><?php echo e($investment->prop_area); ?></small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Contact: <small
                                                        class="text-dark"><?php echo e($investment->seller_contact); ?></small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Seller: <small class="text-dark">
                                                        <?php echo e($investment->seller_name); ?>

                                                    </small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Seller CNIC: <small class="text-dark">
                                                        <?php echo e($investment->seller_cnic); ?>

                                                    </small>
                                                </h3>
                                                <h3 class="fw-bold text-primary" style="font-size: 17px;">
                                                    Description:
                                                    <small class="fw-bold text-dark">
                                                        <p class="py-2"><?php echo e($investment->prop_desc); ?></p>
                                                    </small>
                                                </h3>
                                            </div>
                                            <!-- Bootstrap crossfade carousel -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-4">
                                    <div class="card">
                                        <h3 class="card-header">Processing Form</h3>
                                        <div class="card-body">
                                            <form action="<?php echo e(route('investDisposed', $investment->invest_id)); ?>"
                                                method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="investment_id"
                                                    value="<?php echo e($investment->invest_id); ?>">
                                                <div class="mb-3">
                                                    <label class="form-label" for="basic-default-fullname">Buyer</label>
                                                    <input type="text" class="form-control" name="buyer_name"
                                                        id="basic-default-fullname" />
                                                </div>
                                                <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div class="mb-3">
                                                    <label class="form-label" for="basic-default-company">Buyer
                                                        Contact</label>
                                                    <input type="text" class="form-control" name="buyer_contact"
                                                        id="basic-default-company" />
                                                </div>
                                                <?php $__errorArgs = ['buyer_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div class="mb-3">
                                                    <label class="form-label" for="basic-default-email">Selling
                                                        Price</label>
                                                    <div class="input-group input-group-merge">
                                                        <input type="text" id="basic-default-email" name="sell_price"
                                                            class="form-control" />
                                                    </div>
                                                </div>
                                                <?php $__errorArgs = ['sell_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div class="mb-3">
                                                    <label class="form-label" for="basic-default-phone">Buyer CNIC</label>
                                                    <input type="text" id="basic-default-phone" name="buyer_cnic"
                                                        class="form-control phone-mask" />
                                                </div>
                                                <?php $__errorArgs = ['buyer_cnic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div class="mb-3">
                                                    <label class="form-label" for="basic-default-phone">Advance</label>
                                                    <input type="text" id="basic-default-phone" name="advance"
                                                        class="form-control phone-mask" />
                                                </div>
                                                <?php $__errorArgs = ['advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div class="mb-3">
                                                    <label class="form-label"
                                                        for="basic-default-message">Agreement/Description</label>
                                                    <textarea id="basic-default-message" class="form-control" name="agreement" placeholder="Describe the Contract"></textarea>
                                                </div>
                                                <?php $__errorArgs = ['agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <button type="submit" class="btn btn-primary">Sold Out</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Row -->
                        </div>
                        <!-- / Content -->


                        <!-- Footer -->
                    <?php $__env->stopSection(); ?>

<?php echo $__env->make('html.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RealEstateSystem\resources\views/html/i-show.blade.php ENDPATH**/ ?>