
<?php $__env->startSection('main-section'); ?>

    <body class="rentPage">
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Menu -->
                <!-- / Menu -->

                <!-- Layout container -->
                <div class="layout-page">
                    <!-- Navbar -->
                    <?php echo $__env->make('html.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- / Navbar -->

                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->

                        <div class="container-xxl flex-grow-1 container-p-y">
                            <div class="row">
                                <div class="col-lg-12 mb-4 order-0">
                                    <div class="col-lg-12 col-md-16">

                                        <?php if(session('success')): ?>
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <?php echo e(session('success')); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                    aria-label="Close"></button>
                                            </div>
                                        <?php else: ?>
                                            <?php if(session('error')): ?>
                                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                    <?php echo e(session('error')); ?>

                                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                        aria-label="Close"></button>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <!-- Large Modal -->
                                        <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel3">Add Property Seeker
                                                        </h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('storeSeeker')); ?>" method="POST"
                                                            enctype="multipart/form-data" class="rentForm" id="rentForm">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-fullname">Seeker Name</label>
                                                                <input type="text" class="form-control" id="propTitle"
                                                                    name="name" />
                                                            </div>
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-fullname">Seeker Contact</label>
                                                                <input type="text" class="form-control" id="propTitle"
                                                                    name="contact" />
                                                            </div>
                                                            <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label for="" class="form-label">Property
                                                                    Type</label>
                                                                <select class="form-select form-select-lg" name="type"
                                                                    id="">
                                                                    <option selected>Select one</option>
                                                                    <option value="rent">Rent</option>
                                                                    <option value="buy">Buy</option>
                                                                </select>
                                                            </div>
                                                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-company">Prefferd Location</label>
                                                                <input type="text" class="form-control" id="propLoc"
                                                                    name="preferred_location" />
                                                            </div>
                                                            <?php $__errorArgs = ['preferred_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-email">Area</label>
                                                                <div class="input-group input-group-merge">
                                                                    <input type="text" id="propArea" class="form-control"
                                                                        name="area" />
                                                                </div>
                                                            </div>
                                                            <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-phone">Budget</label>
                                                                <input type="text" id="propDemand"
                                                                    class="form-control phone-mask" name="budget" />
                                                            </div>
                                                            <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-message">Description</label>
                                                                <textarea id="propDesc" class="form-control"
                                                                    placeholder="Describe things about Property"
                                                                    name="description"></textarea>
                                                            </div>
                                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <button id="rentSubmit" type="submit"
                                                                class="btn btn-primary">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <h1 style="font-size: 20px; font-weight: 700; padding-top: 16px;">Property
                                                Seekers</h1>
                                            <div class="d-flex justify-content-between flex-wrap gap-3">
                                                <span class="d-flex gap-2">
                                                    <span>
                                                        <button id="addRent" type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal" data-bs-target="#largeModal">
                                                            Add Seeker
                                                        </button>
                                                    </span>
                                                </span>
                                                <span class="d-flex">
                                                    <form action="<?php echo e(route('showSeekers')); ?>" method="GET"
                                                        class="d-flex gap-2">
                                                        <div class="mb-3">
                                                            <input type="text"
                                                                class="form-control border-0 shadow-none ps-1 ps-sm-2"
                                                                placeholder="Search..." aria-label="Search..."
                                                                name="search" />
                                                        </div>
                                                        <div>
                                                            <input type="submit" class="btn btn-primary">
                                                        </div>
                                                        <div>
                                                            <a href="<?php echo e(route('showSeekers')); ?>"
                                                                class="btn btn-success">Reset</a>
                                                        </div>
                                                    </form>
                                                </span>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4 order-0">
                                    <div class="card">
                                        <h5 class="card-header">Seeker</h5>
                                        <div class="table-responsive text-nowrap">
                                            <table class="table" id="rentTable">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Contact</th>
                                                        <th>Type</th>
                                                        <th>Area</th>
                                                        <th>Prefered Location</th>
                                                        <th>Budget</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $seekers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><span class="fw-medium"><?php echo e($property['name']); ?></span>
                                                            </td>
                                                            <td><?php echo e($property['contact']); ?></td>
                                                            <td>
                                                                <?php if($property['type'] == 'rent'): ?>
                                                                    Rent
                                                                <?php else: ?>
                                                                    Buy
                                                                <?php endif; ?>
                                                            </td>
                                                            </td>
                                                            <td> <?php echo e($property['area']); ?>

                                                            </td>
                                                            <td><?php echo e($property['preferred_location']); ?></td>
                                                            <td><?php echo e($property['budget']); ?></td>
                                                            <td>
                                                                <?php if($property['status'] == 'pending'): ?>
                                                                    <span class="badge bg-label-primary">Pending</span>
                                                                <?php elseif($property['status'] == 'contacted'): ?>
                                                                    <span class="badge bg-label-secondary">Contacted</span>
                                                                <?php elseif($property['status'] == 'closed'): ?>
                                                                    <span class="badge bg-label-danger">Closed</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <div class="dropdown">
                                                                    <button type="button"
                                                                        class="btn p-0 dropdown-toggle hide-arrow"
                                                                        data-bs-toggle="dropdown">
                                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                                    </button>
                                                                    <div class="dropdown-menu">
                                                                        <a class="dropdown-item"
                                                                            href="<?php echo e(route('seekerDetails', $property['id'])); ?>"><i
                                                                                class="fa-regular fa-eye me-1"></i>
                                                                            Preview</a>
                                                                        <a class="dropdown-item"
                                                                            href="<?php echo e(route('deleteSeeker', $property['id'])); ?>"><i
                                                                                class="bx bx-trash me-1"></i> Delete</a>
                                                                        <?php if($property['status'] == 'pending'): ?>
                                                                            <hr>
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('seekerContacted', $property['id'])); ?>">
                                                                                <i class='bx  bx-phone-outgoing'></i>
                                                                                Contacted</a>
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('seekerClosed', $property['id'])); ?>">
                                                                                <i class='bx  bx-arrow-out-down-right-square'></i>
                                                                                Closed</a>
                                                                        <?php elseif($property['status'] == 'contacted'): ?>
                                                                            <hr>
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('seekerClosed', $property['id'])); ?>">
                                                                                <i class="fa-regular fa-square-check"></i>
                                                                                Closed</a>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="demo-inline-spacing">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        <?php if($seekers->onfirstPage()): ?>
                                                        <li class="page-item prev disabled">
                                                            <a class="page-link"></a>
                                                        </li>
                                                        <?php else: ?>
                                                        <li class="page-item prev">
                                                            <a href="<?php echo e($seekers->previousPageUrl()); ?>"
                                                                class="page-link">Previous</a>
                                                        </li>
                                                        <?php endif; ?>
                                                        <?php $__currentLoopData = $seekers->getUrlRange(1, $seekers->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($page == $seekers->currentPage()): ?>
                                                        <li class="page-item active">
                                                            <a class="page-link" href="#"><?php echo e($page); ?></a>
                                                        </li>
                                                        <?php else: ?>
                                                        <li class="page-item">
                                                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                        </li>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($seekers->hasMorePages()): ?>
                                                        <li class="page-item next">
                                                            <a class="page-link" href="<?php echo e($seekers->nextPageUrl()); ?>"><i
                                                                    class="tf-icon bx bx-chevron-right"></i></a>
                                                        </li>
                                                        <?php else: ?>
                                                        <li class="page-item next">
                                                            <a class="page-link" href="#"><i
                                                                    class="tf-icon bx bx-chevron-right"></i></a>
                                                        </li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </nav>
                                                <!--/ Basic Pagination -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Row -->
                        </div>
                        <!-- / Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RealEstateSystem\resources\views/html/propertySeekers.blade.php ENDPATH**/ ?>