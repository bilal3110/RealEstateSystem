
<?php $__env->startSection('main-section'); ?>

    <body>
        <!-- Layout wrapper -->
        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Menu -->

                <!-- / Menu -->

                <!-- Layout container -->
                <div class="layout-page">
                    <!-- Navbar -->
                    <?php echo $__env->make('html.layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <!-- / Navbar -->

                    <!-- Content wrapper -->
                    <div class="content-wrapper">
                        <!-- Content -->
                        <div class="container-xxl flex-grow-1 container-p-y">
                            <div class="row">
                                <div class="col-lg-12 mb-4 order-0">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <?php echo e(session('success')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php else: ?>
                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                <?php echo e(session('error')); ?>

                                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                    aria-label="Close"></button>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div class="col-lg-12 col-md-6">
                                        <!-- Large Modal -->
                                        <div class="modal fade" id="largeModal" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel3">Add Property You
                                                            Invest In</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('addInvestment')); ?>" method="POST"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-fullname">Title</label>
                                                                <input type="text" class="form-control"
                                                                    id="basic-default-fullname" name="prop_title" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-company">Location</label>
                                                                <input type="text" class="form-control"
                                                                    id="basic-default-company" name="prop_loc" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-email">Area</label>
                                                                <div class="input-group input-group-merge">
                                                                    <input type="text" id="basic-default-email"
                                                                        class="form-control" name="prop_area" />
                                                                </div>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">Seller
                                                                    Name</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask" name="seller_name" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">Seller
                                                                    Contact</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask"
                                                                    name="seller_contact" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">Seller
                                                                    CNIC</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask" name="seller_cnic" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">Buying
                                                                    Price</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask" name="buying_price" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">My
                                                                    Equity</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask" name="my_equity" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label" for="basic-default-phone">My
                                                                    Investment</label>
                                                                <input type="text" id="basic-default-phone"
                                                                    class="form-control phone-mask"
                                                                    name="my_investment" />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-phone">Images</label>
                                                                <input class="form-control" type="file"
                                                                    id="formFileMultiple" name="prop_img[]" multiple />
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label"
                                                                    for="basic-default-message">Description</label>
                                                                <textarea id="basic-default-message" class="form-control" placeholder="Describe things about Property"
                                                                    name="prop_desc"></textarea>
                                                            </div>
                                                            <button type="submit" class="btn btn-primary">Send</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <h1 style="font-size: 20px; font-weight: 700; padding-top: 10px;">Your
                                                Investments</h1>
                                            <div class="d-flex justify-content-between flex-wrap gap-3">
                                                <span class="d-flex gap-2">
                                                    <span>
                                                        <button type="button" class="btn btn-primary"
                                                            data-bs-toggle="modal" data-bs-target="#largeModal">
                                                            Add Property
                                                        </button>
                                                    </span>
                                                    <span>
                                                        <a href="<?php echo e(route('investDisposedShow')); ?>"
                                                            class="btn btn-success">Disposed</a>
                                                    </span>
                                                </span>
                                                <span class="d-flex">
                                                    <form action="<?php echo e(route('showInvestment')); ?>" method="GET"
                                                        class="d-flex gap-2">
                                                        <div class="mb-3">
                                                            <input type="text"
                                                                class="form-control border-0 shadow-none ps-1 ps-sm-2"
                                                                placeholder="Search..." aria-label="Search..."
                                                                name="search" />
                                                        </div>
                                                        <div>
                                                            <input type="submit" class="btn btn-primary">
                                                        </div>
                                                        <div>
                                                            <a href="<?php echo e(route('showInvestment')); ?>"
                                                                class="btn btn-success">Reset</a>
                                                        </div>
                                                        <div>
                                                            <a href="<?php echo e(route('showHold')); ?>"
                                                                class="btn btn-outline-primary">Hold</a>
                                                        </div>
                                                        <div>
                                                            <a href="<?php echo e(route('showSold')); ?>"
                                                                class="btn btn-outline-success">Sold</a>
                                                        </div>
                                                    </form>
                                                </span>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-4 order-0">
                                    <div class="card">
                                        <h5 class="card-header">Investment</h5>
                                        <div class="table-responsive text-nowrap">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Property</th>
                                                        <th>Seller Name</th>
                                                        <th>Area</th>
                                                        <th>Seller CNIC</th>
                                                        <th>Buying Price</th>
                                                        <th>My Equity</th>
                                                        <th>My Investment</th>
                                                        <th>Status</th>
                                                        <th>Actions</th>
                                                    </tr>

                                                </thead>
                                                <tbody class="table-border-bottom-0">
                                                    <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($investment->prop_title); ?></td>
                                                            <td><?php echo e($investment->seller_name); ?></td>
                                                            <td><?php echo e($investment->prop_area); ?></td>
                                                            <td><?php echo e($investment->seller_cnic); ?></td>
                                                            <td><?php echo e(number_format((float) str_replace(',', '', $investment->buying_price))); ?>

                                                            </td>
                                                            <td><?php echo e($investment->my_equity); ?> %</td>
                                                            <td><?php echo e(number_format((float) str_replace(',', '', $investment->my_investment))); ?>

                                                            </td>
                                                            <td>
                                                                <?php if($investment->is_sold == 0): ?>
                                                                    <span class="badge bg-label-primary">Hold</span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-label-success">Sold</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <div class="dropdown">
                                                                    <button type="button"
                                                                        class="btn p-0 dropdown-toggle hide-arrow"
                                                                        data-bs-toggle="dropdown">
                                                                        <i class="bx bx-dots-vertical-rounded"></i>
                                                                    </button>
                                                                    <div class="dropdown-menu">
                                                                        <?php if($investment->is_sold == 0): ?>
                                                                            <a class="dropdown-item"
                                                                                href="<?php echo e(route('showProperty', $investment->invest_id)); ?>"><i
                                                                                    class="fa-regular fa-eye me-1"></i>
                                                                                Preview</a>
                                                                        <?php endif; ?>
                                                                        <a class="dropdown-item"
                                                                            href="<?php echo e(route('deleteInvestment', $investment->invest_id)); ?>"><i
                                                                                class="bx bx-trash me-1"></i> Delete</a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-12 mb-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="demo-inline-spacing">
                                                <nav aria-label="Page navigation">
                                                    <ul class="pagination">
                                                        <?php if($investments->onfirstPage()): ?>
                                                            <li class="page-item prev disabled">
                                                                <a class="page-link"></a>
                                                            </li>
                                                        <?php else: ?>
                                                            <li class="page-item prev">
                                                                <a href="<?php echo e($investments->previousPageUrl()); ?>"
                                                                    class="page-link">Previous</a>
                                                            </li>
                                                        <?php endif; ?>
                                                        <?php $__currentLoopData = $investments->getUrlRange(1, $investments->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($page == $investments->currentPage()): ?>
                                                                <li class="page-item active">
                                                                    <a class="page-link"
                                                                        href="#"><?php echo e($page); ?></a>
                                                                </li>
                                                            <?php else: ?>
                                                                <li class="page-item">
                                                                    <a class="page-link"
                                                                        href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                                </li>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($investments->hasMorePages()): ?>
                                                            <li class="page-item next">
                                                                <a class="page-link"
                                                                    href="<?php echo e($investments->nextPageUrl()); ?>"><i
                                                                        class="tf-icon bx bx-chevron-right"></i></a>
                                                            </li>
                                                        <?php else: ?>
                                                            <li class="page-item next">
                                                                <a class="page-link" href="#"><i
                                                                        class="tf-icon bx bx-chevron-right"></i></a>
                                                            </li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </nav>
                                                <!--/ Basic Pagination -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Row -->
                        </div>
                        <!-- / Content -->
                    <?php $__env->stopSection(); ?>

<?php echo $__env->make('html.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RealEstateSystem\resources\views/html/investment.blade.php ENDPATH**/ ?>